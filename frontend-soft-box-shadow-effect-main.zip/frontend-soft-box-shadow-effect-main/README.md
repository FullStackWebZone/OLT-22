# Soft Box Shadow Effect

## Tecnologias:
<br>
<img src="https://img.shields.io/static/v1?label=HTML&message=5&color=E34F26&style=plastic&logo=html5"/>


<img src="https://img.shields.io/static/v1?label=CSS&message=3&color=1572B6&style=plastic&logo=css3"/>

<br>
<br>
<h1 align="center">
  <img alt="Soft Box Shadow Effect" title="#Soft Box Shadow Effect" src="./assets/project-39.gif" />
</h1>