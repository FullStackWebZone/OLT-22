# glowing-text-animation-effects
Creating a glowing text animation effects.

## Screenshot
![screen jpeg](https://user-images.githubusercontent.com/62728037/140295763-7b294315-5695-4190-975c-6696691e2c1f.jpg)


Live Site URL: https://cleitonrs.github.io/glowing-text-animation-effects/
