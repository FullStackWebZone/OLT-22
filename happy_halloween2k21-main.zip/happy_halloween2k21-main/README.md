## Halloween Website 🎃

- Responsive Halloween Website Using HTML, CSS & JavaScript.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

## What new things I learnt

- Scrolling animations
- Developing first with the Mobile First methodology, then for desktop.

#### Attribution: [Bedimcode](https://www.youtube.com/c/Bedimcode)
